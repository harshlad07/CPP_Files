#include<iostream>
using namespace std;

class cal
{
	public:
		int x,y;
		void input(int i1, int i2)
		{
			x = i1;
			y = i2;
		}
		int add();
		int sub();		
		int mul();
		int divi();
};

int cal :: add()
{
	return (x+y);
}
int cal :: sub()
{
	if(x>y)
	{
		return (x-y);
	}
	else
	{
		return (y-x);
	}
}

int cal :: mul()
{
	return (x*y);
}
int cal :: divi()
{
	return (x/y);
}
int main()
{
	cal c;
	int a,b;
	cout<<"\nEnter first new number - ";
	cin>>a;
	cout<<"\nEnter second number - ";
	cin>>b;
	c.input(a,b);
	cout<<"\nAddition - "<<c.add();
	cout<<"\nSuubtraction - "<<c.sub();
	cout<<"\nMultiplication - "<<c.mul();
	cout<<"\nDivision - "<<c.divi()<<endl;
}